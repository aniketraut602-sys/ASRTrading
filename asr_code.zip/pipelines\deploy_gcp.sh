#!/bin/bash

# Deploy to GCP
# Usage: ./deploy_gcp.sh

set -e

# 1. Pre-flight checks
if ! command -v gcloud &> /dev/null; then
    echo "Error: gcloud CLI not found."
    exit 1
fi

if ! command -v terraform &> /dev/null; then
  echo "Error: terraform not found"
  exit 1
fi

echo "=== ASR Trading GCP Deployment ==="

# 2. Get Infrastructure Info
echo "Reading Terraform Output..."
cd infra
# Ensure we have state (assuming terraform apply was run)
# We use -raw to get just the string.
# Note: If terraform isn't applied, this fails.
INSTANCE_IP=$(terraform output -raw public_ip 2>/dev/null || echo "")

if [ -z "$INSTANCE_IP" ]; then
    echo "Error: Could not get public_ip from Terraform."
    echo "Please run 'terraform apply' in 'infra/' first."
    exit 1
fi

echo "Target Instance IP: $INSTANCE_IP"
cd ..

# 3. Deploy Code (SCM Sync)
# Strategy: SSH into box, git pull, rerun setup.

echo "Deploying to $INSTANCE_IP..."

# Assumes active gcloud login or SSH key setup.
# We'll use gcloud compute ssh for convenience as it handles keys.
# Zone is hardcoded or should be fetched.
ZONE="asia-south1-a"
INSTANCE_NAME="asr-trading-production"

echo "Syncing code & Restarting service..."
gcloud compute ssh --zone "$ZONE" "$INSTANCE_NAME" --command "
    cd /opt/asr_trading
    # If it's a git repo, pull. If we rely on scp, we'd do that before.
    # For now, assuming git workflow for 'Production'
    if [ -d .git ]; then
        git pull origin main
    fi
    
    # Run setup to update deps
    sudo ./pipelines/scripts/setup_ubuntu.sh
    
    # Restart service
    sudo systemctl restart asr_trading
    
    # Check status
    systemctl status asr_trading --no-pager
"

echo "=== Deployment Triggered Successfully ==="
